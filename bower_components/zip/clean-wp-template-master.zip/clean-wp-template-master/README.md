your-clean-template-3
=================

This is clean WordPress theme with minimal bootstrap3 html5 markup for fast development starting yours project on WordPress.

Contain only the necessary and sufficient set of files and functionality.

Suitable for those who often makes sites on WordPress and beginners to understand how it works.

Donate - <a href="http://dontforget.pro/donate/" target="_blank">thanks dontforget.pro</a>


