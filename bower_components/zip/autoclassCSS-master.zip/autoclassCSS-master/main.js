module.exports = require('./autoclasscss').Autoclasscss;
